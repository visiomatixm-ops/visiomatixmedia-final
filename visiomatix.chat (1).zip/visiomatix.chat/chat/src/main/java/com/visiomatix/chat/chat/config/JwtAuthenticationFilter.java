/**
 * ===========================================================
 * Filename: JwtAuthenticationFilter.java
 * Location: com.visiomatix.chat.chat.config
 * Author: Viral Prajapati
 * Date: 29-Oct-2025
 * Description:
 *   Security filter that intercepts every incoming HTTP request
 *   once per request to:
 *   - Extract and validate JWT token from Authorization header.
 *   - Authenticate user if token is valid.
 *   - Populate SecurityContext with proper authorities.
 * ===========================================================
 */

package com.visiomatix.chat.chat.config;

import com.visiomatix.chat.chat.user.util.JwtUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    // Logger for debug and warning messages
    private static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

    // Dependencies
    private final JwtUtil jwtUtil;
    private final UserDetailsService userDetailsService;

    // Constructor injection
    public JwtAuthenticationFilter(JwtUtil jwtUtil, UserDetailsService userDetailsService) {
        this.jwtUtil = jwtUtil;
        this.userDetailsService = userDetailsService;
    }

    /**
     * Main filter method — executes for every HTTP request.
     */
    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain
    ) throws ServletException, IOException {

        try {
            // 1️⃣ Extract the Authorization header
            String header = request.getHeader("Authorization");
            String token = null;
            String username = null;

            // 2️⃣ Check header validity and extract JWT
            if (StringUtils.hasText(header) && header.startsWith("Bearer ")) {
                token = header.substring(7);

                try {
                    username = jwtUtil.extractUsername(token);
                    logger.debug("Extracted username from JWT: {}", username);
                } catch (Exception e) {
                    logger.warn("Failed to extract username from JWT: {}", e.getMessage(), e);
                }
            }

            // 3️⃣ Proceed only if username is found and user not yet authenticated
            if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {

                // Load user details (fetches roles/authorities)
                UserDetails userDetails = userDetailsService.loadUserByUsername(username);

                // Validate token and username
                if (jwtUtil.validateToken(token, username)) {
                    UsernamePasswordAuthenticationToken authToken =
                            new UsernamePasswordAuthenticationToken(
                                    userDetails,
                                    null,
                                    userDetails.getAuthorities()
                            );

                    // Attach request context
                    authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                    // Set authenticated user in SecurityContext
                    SecurityContextHolder.getContext().setAuthentication(authToken);
                    logger.debug("✅ Authentication successful for user: {}", username);
                } else {
                    logger.warn("❌ Invalid JWT token for user: {}", username, new Exception("Token validation failed"));
                }
            }
        } catch (Exception ex) {
            logger.error("⚠️ Error in JWT filter: {}", ex.getMessage(), ex);
        }

        // Continue with filter chain (always call once)
        filterChain.doFilter(request, response);
    }
}
