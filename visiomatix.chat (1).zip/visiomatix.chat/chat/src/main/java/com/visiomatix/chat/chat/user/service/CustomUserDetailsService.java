/**
 * ===========================================================
 * File: CustomUserDetailsService.java
 * Location: com.visiomatix.chat.chat.user.service
 * Author: Viral Prajapati
 * Date: 29-Oct-2025
 * Description:
 *   Implementation of Spring Security's UserDetailsService.
 *   Dynamically loads user authorities (roles + permissions)
 *   from the database, including extended role types such as
 *   CUSTOMER_SUCCESS_LEAD.
 *
 * ===========================================================
 */

package com.visiomatix.chat.chat.user.service;

import com.visiomatix.chat.chat.user.model.Permission;
import com.visiomatix.chat.chat.user.model.Privilege;
import com.visiomatix.chat.chat.user.model.Role;
import com.visiomatix.chat.chat.user.model.User;
import com.visiomatix.chat.chat.user.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * CustomUserDetailsService
 * ------------------------
 * Loads user details (with roles and permissions) from database
 * for Spring Security authentication and authorization.
 */
@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;

    @Autowired
    public CustomUserDetailsService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Load user by username (email or username)
     * and assign dynamic authorities:
     * - ROLE_<RoleName>
     * - <PrivilegeName>
     * - <PermissionName>
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Fetch user from DB
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));

        // Gather roles + privileges + permissions dynamically
        Set<GrantedAuthority> authorities = new HashSet<>();

        for (Role role : user.getRoles()) {
            // Add role-based authority
            authorities.add(new SimpleGrantedAuthority("ROLE_" + role.getName()));

            // Add all privileges associated with this role
            if (role.getPrivileges() != null) {
                for (Privilege privilege : role.getPrivileges()) {
                    authorities.add(new SimpleGrantedAuthority(privilege.getName()));

                    // Add all permissions associated with this privilege
                    if (privilege.getPermissions() != null) {
                        Set<GrantedAuthority> privilegePermissions = privilege.getPermissions().stream()
                                .map(Permission::getName)
                                .map(SimpleGrantedAuthority::new)
                                .collect(Collectors.toSet());
                        authorities.addAll(privilegePermissions);
                    }
                }
            }

            // Add all permissions associated with this role
            if (role.getPermissions() != null) {
                Set<GrantedAuthority> rolePermissions = role.getPermissions().stream()
                        .map(Permission::getName)
                        .map(SimpleGrantedAuthority::new)
                        .collect(Collectors.toSet());
                authorities.addAll(rolePermissions);
            }

            // Handle extended roles like CUSTOMER_SUCCESS_LEAD
            if (role.getName().equalsIgnoreCase("CUSTOMER_SUCCESS_LEAD")) {
                authorities.add(new SimpleGrantedAuthority("ROLE_CUSTOMER_SUCCESS_LEAD"));
                authorities.add(new SimpleGrantedAuthority("VIEW_CUSTOMER_DATA"));
                authorities.add(new SimpleGrantedAuthority("MANAGE_CHAT_ASSIGNMENTS"));
                authorities.add(new SimpleGrantedAuthority("GENERATE_REPORTS"));
            }
        }

        // Construct Spring Security user with dynamic authorities
        return org.springframework.security.core.userdetails.User
                .withUsername(user.getUsername())
                .password(user.getPassword())
                .authorities(authorities)
                .accountExpired(false)
                .accountLocked(false)
                .credentialsExpired(false)
                .disabled(false)
                .build();
    }
}
