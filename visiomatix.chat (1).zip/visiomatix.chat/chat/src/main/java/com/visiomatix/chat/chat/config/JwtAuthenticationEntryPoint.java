/**
 * ===========================================================
 * Filename: JwtAuthenticationEntryPoint.java
 * Location: com.visiomatix.chat.chat.config
 * Author: Viral Prajapati
 * Date: 29-Oct-2025
 * Description:
 *   Custom entry point for handling unauthorized access.
 *   Ensures API returns JSON response instead of default login redirect.
 * ===========================================================
 */

package com.visiomatix.chat.chat.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;
import org.springframework.http.MediaType;
import java.io.IOException;
import java.io.StringWriter;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint {

    @Override
    public void commence(
            HttpServletRequest request,
            HttpServletResponse response,
            org.springframework.security.core.AuthenticationException authException)
            throws IOException {

        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

        Map<String, Object> errorDetails = new HashMap<>();
        errorDetails.put("timestamp", LocalDateTime.now().toString());
        errorDetails.put("status", HttpServletResponse.SC_UNAUTHORIZED);
        errorDetails.put("error", "Unauthorized");
        errorDetails.put("message", authException.getMessage() != null ? authException.getMessage() : "Invalid or missing JWT token");
        errorDetails.put("details", authException.getClass().getSimpleName() + ": " + authException.getLocalizedMessage());
        errorDetails.put("path", request.getRequestURI());

        // Include full stack trace for debugging
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        authException.printStackTrace(pw);
        errorDetails.put("stackTrace", sw.toString());

        new ObjectMapper().writeValue(response.getOutputStream(), errorDetails);
    }
}
