
/**
 * =====================================================================================
 * File Name   : GlobalExceptionHandler.java
 * Location    : src/main/java/com/visiomatix/chat/exception/
 * Author      : Viral Prajapati
 * Created On  : 14-Oct-2025
 * Description :
 *   Phase 3 Enhancement
 *   -------------------
 *   This class provides centralized exception handling for REST API endpoints.
 *   It ensures that any runtime exceptions or validation errors are returned
 *   in a structured, user-friendly JSON format instead of raw stack traces.
 *
 *   Key Features:
 *     - Handles general RuntimeExceptions with custom message.
 *     - Handles javax.validation constraint violations (@Valid/@Validated errors).
 *     - Provides consistent JSON structure for all API errors.
 *
 *   Example JSON Response:
 *   -----------------------
 *   {
 *       "timestamp": "2025-10-14T10:15:30.123",
 *       "status": 400,
 *       "error": "Bad Request",
 *       "message": "Username is required",
 *       "path": "/api/users/register"
 *   }
 *
 * =====================================================================================
 */

package com.visiomatix.chat.chat.exception;

// ============================================================
// Import Statements
// ============================================================
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.io.StringWriter;
import java.io.PrintWriter;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
// ============================================================
// Class Declaration
// ============================================================
/**
 * GlobalExceptionHandler
 * ----------------------
 * Handles all exceptions thrown by REST controllers.
 * Centralized exception handling for user-friendly error messages.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    // ============================================================
    // Handle all RuntimeExceptions
    // ============================================================
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<Map<String, Object>> handleRuntimeException(RuntimeException ex, WebRequest request) {
        logger.error("RuntimeException occurred: ", ex);
        Map<String, Object> body = new HashMap<>();
        body.put("timestamp", LocalDateTime.now().toString());
        body.put("status", HttpStatus.BAD_REQUEST.value());
        body.put("error", "Bad Request");
        body.put("message", ex.getMessage());
        body.put("details", ex.getClass().getSimpleName() + ": " + ex.getLocalizedMessage());
        body.put("path", request.getDescription(false).replace("uri=", ""));

        // Include full stack trace for debugging
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        ex.printStackTrace(pw);
        body.put("stackTrace", sw.toString());

        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }

    // ============================================================
    // Handle validation errors for @Valid/@Validated DTOs
    // ============================================================
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidationException(MethodArgumentNotValidException ex, WebRequest request) {
        logger.error("ValidationException occurred: ", ex);
        Map<String, Object> body = new HashMap<>();
        body.put("timestamp", LocalDateTime.now().toString());
        body.put("status", HttpStatus.BAD_REQUEST.value());
        body.put("error", "Validation Error");

        // Collect all field errors
        Map<String, String> fieldErrors = new HashMap<>();
        for (FieldError error : ex.getBindingResult().getFieldErrors()) {
            fieldErrors.put(error.getField(), error.getDefaultMessage());
        }
        body.put("message", fieldErrors);
        body.put("details", "Validation failed for " + fieldErrors.size() + " field(s)");
        body.put("path", request.getDescription(false).replace("uri=", ""));

        // Include full stack trace for debugging
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        ex.printStackTrace(pw);
        body.put("stackTrace", sw.toString());

        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }

    // ============================================================
    // Handle Security Exceptions
    // ============================================================
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<Map<String, Object>> handleAccessDeniedException(AccessDeniedException ex, WebRequest request) {
        logger.warn("Access denied: ", ex);
        Map<String, Object> body = new HashMap<>();
        body.put("timestamp", LocalDateTime.now().toString());
        body.put("status", HttpStatus.FORBIDDEN.value());
        body.put("error", "Forbidden");
        body.put("message", "Access denied. You do not have permission to access this resource.");
        body.put("details", "Required authority not found in user's granted authorities");
        body.put("path", request.getDescription(false).replace("uri=", ""));

        // Include full stack trace for debugging
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        ex.printStackTrace(pw);
        body.put("stackTrace", sw.toString());

        return new ResponseEntity<>(body, HttpStatus.FORBIDDEN);
    }

    @ExceptionHandler(AuthenticationException.class)
    public ResponseEntity<Map<String, Object>> handleAuthenticationException(AuthenticationException ex, WebRequest request) {
        logger.warn("Authentication failed: ", ex);
        Map<String, Object> body = new HashMap<>();
        body.put("timestamp", LocalDateTime.now().toString());
        body.put("status", HttpStatus.UNAUTHORIZED.value());
        body.put("error", "Unauthorized");
        body.put("message", "Authentication failed. Please check your credentials.");
        body.put("details", ex.getClass().getSimpleName() + ": " + ex.getLocalizedMessage());
        body.put("path", request.getDescription(false).replace("uri=", ""));

        // Include full stack trace for debugging
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        ex.printStackTrace(pw);
        body.put("stackTrace", sw.toString());

        return new ResponseEntity<>(body, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(UsernameNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleUsernameNotFoundException(UsernameNotFoundException ex, WebRequest request) {
        logger.warn("User not found: ", ex);
        Map<String, Object> body = new HashMap<>();
        body.put("timestamp", LocalDateTime.now().toString());
        body.put("status", HttpStatus.UNAUTHORIZED.value());
        body.put("error", "Unauthorized");
        body.put("message", "User not found. Please check your username.");
        body.put("details", ex.getClass().getSimpleName() + ": " + ex.getLocalizedMessage());
        body.put("path", request.getDescription(false).replace("uri=", ""));

        // Include full stack trace for debugging
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        ex.printStackTrace(pw);
        body.put("stackTrace", sw.toString());

        return new ResponseEntity<>(body, HttpStatus.UNAUTHORIZED);
    }

    // ============================================================
    // Handle any other uncaught exceptions
    // ============================================================
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGenericException(Exception ex, WebRequest request) {
        logger.error("Unexpected exception occurred: ", ex);
        Map<String, Object> body = new HashMap<>();
        body.put("timestamp", LocalDateTime.now().toString());
        body.put("status", HttpStatus.INTERNAL_SERVER_ERROR.value());
        body.put("error", "Internal Server Error");
        body.put("message", ex.getMessage());
        body.put("details", ex.getClass().getSimpleName() + ": " + ex.getLocalizedMessage());
        body.put("path", request.getDescription(false).replace("uri=", ""));

        // Include full stack trace for debugging
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        ex.printStackTrace(pw);
        body.put("stackTrace", sw.toString());

        return new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
