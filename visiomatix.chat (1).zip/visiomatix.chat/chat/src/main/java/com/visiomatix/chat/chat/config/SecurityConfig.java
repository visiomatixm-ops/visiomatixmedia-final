/**
 * ===========================================================
 * File: SecurityConfig.java
 * Location: com.visiomatix.chat.chat.config
 * Author: Viral Prajapati
 * Date: 29-Oct-2025
 * Description:
 *  Configures Spring Security for JWT-based stateless authentication.
 *  Enhancements:
 *   - Integrates fixed JwtAuthenticationFilter & EntryPoint
 *   - Prepares for dynamic role/permission-driven authorization
 *   - Centralized CORS setup
 *   - Stateless, no form or basic auth
 * ===========================================================
 */

package com.visiomatix.chat.chat.config;

// ===========================================================
// Import Statements
// ===========================================================
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import java.util.List;

// Custom Security Components
import com.visiomatix.chat.chat.config.JwtAuthenticationFilter;

@Configuration
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    // ===========================================================
    // Field Declarations
    // ===========================================================
    private final UserDetailsService userDetailsService;
    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final AuthenticationEntryPoint unauthorizedHandler;

    // ===========================================================
    // Constructor Injection
    // ===========================================================
    public SecurityConfig(
            UserDetailsService userDetailsService,
            JwtAuthenticationFilter jwtAuthenticationFilter,
            AuthenticationEntryPoint unauthorizedHandler) {
        this.userDetailsService = userDetailsService;
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
        this.unauthorizedHandler = unauthorizedHandler;
    }

    // ===========================================================
    // Bean Declaration - Password Encoder
    // ===========================================================
    @Bean
    public PasswordEncoder passwordEncoder() {
        // BCrypt is a strong one-way hashing function for passwords.
        return new BCryptPasswordEncoder();
    }

    // ===========================================================
    // Bean Declaration - Authentication Manager
    // ===========================================================
    @Bean
    public AuthenticationManager authenticationManager() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder());
        return new ProviderManager(provider);
    }

    // ===========================================================
    // Bean Declaration - CORS Configuration Source
    // ===========================================================
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOriginPatterns(List.of(
            "http://localhost:*",
            "http://127.0.0.1:*",
            "http://0.0.0.0:*",
            "https://*.visiomatix.com"
        ));
        configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"));
        configuration.setAllowedHeaders(List.of("*"));
        configuration.setExposedHeaders(List.of("Authorization", "Content-Type", "Cache-Control"));
        configuration.setAllowCredentials(true);
        configuration.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }

    // ===========================================================
    // Bean Declaration - Security Filter Chain
    // ===========================================================
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
            // 1️⃣ Enable custom CORS policy
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))

            // 2️⃣ Disable CSRF since we’re using JWT (no session)
            .csrf(csrf -> csrf.disable())

            // 3️⃣ Handle unauthorized access via custom entry point
            .exceptionHandling(ex -> ex.authenticationEntryPoint(unauthorizedHandler))

            // 4️⃣ Stateless session policy
            .sessionManagement(session ->
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            )

            // 5️⃣ Authorization rules
            .authorizeHttpRequests(auth -> auth

                // Public Endpoints (Allow All)
                .requestMatchers("/api/auth/login", "/api/auth/register").permitAll()
                .requestMatchers("/api/users/register", "/api/users/login").permitAll()
                .requestMatchers("/ws/**", "/ws-chat/**", "/h2-console/**").permitAll()

                // Chat APIs (Authenticated)
                .requestMatchers("/api/chat/**").authenticated()

                // Admin APIs with custom role-based access control
                // Agent can access their own data and basic admin functions
                .requestMatchers("/api/admin/users/*/chat-stats/**").hasAnyAuthority("ROLE_ADMIN", "ROLE_AGENT")
                .requestMatchers("/api/admin/users/*/sessions").hasAnyAuthority("ROLE_ADMIN", "ROLE_AGENT")
                .requestMatchers("/api/admin/sessions/*/details").hasAnyAuthority("ROLE_ADMIN", "ROLE_AGENT")

                // Full admin access for admin role only
                .requestMatchers("/api/admin/users").hasAuthority("ROLE_ADMIN")
                .requestMatchers("/api/admin/roles").hasAuthority("ROLE_ADMIN")
                .requestMatchers("/api/admin/permissions").hasAuthority("ROLE_ADMIN")
                .requestMatchers("/api/admin/privileges").hasAuthority("ROLE_ADMIN")
                .requestMatchers("/api/admin/statistics").hasAuthority("ROLE_ADMIN")
                .requestMatchers("/api/admin/**").hasAuthority("ROLE_ADMIN")

                // Customer Success Lead specific endpoints
                .requestMatchers("/api/admin/customer-data/**").hasAuthority("VIEW_CUSTOMER_DATA")
                .requestMatchers("/api/admin/chat-assignments/**").hasAuthority("MANAGE_CHAT_ASSIGNMENTS")
                .requestMatchers("/api/admin/reports/**").hasAuthority("GENERATE_REPORTS")

                // Any other API endpoint requires authentication
                .requestMatchers("/api/**").authenticated()

                // All others (static content, index.html, etc.)
                .anyRequest().permitAll()
            )

            // 6️⃣ Disable default form/basicauth (JWT replaces them)
            .httpBasic(basic -> basic.disable())
            .formLogin(form -> form.disable())
            .logout(logout -> logout.disable());

        // 7️⃣ Add JWT authentication filter before UsernamePasswordAuthenticationFilter
        http.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        // 8️⃣ Allow frame access for H2 console
        http.headers(headers -> headers.frameOptions(frame -> frame.disable()));

        return http.build();
    }
}
