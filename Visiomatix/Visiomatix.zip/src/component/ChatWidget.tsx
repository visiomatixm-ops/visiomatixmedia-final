/**
 * ===========================================================
 * File: ChatWidget.tsx
 * Author: Viral Prajapati
 * Date: 16-Oct-2025
 * Description:
 *  Floating chat widget (bottom-right) for default users.
 *  - Connects to backend via REST + WebSocket.
 *  - Opens a popup chat window when CTA clicked.
 * ===========================================================
 */
import React, { useEffect, useState } from "react";
import SockJS from "sockjs-client";
import { Client } from "@stomp/stompjs";
import { CompatClient, Stomp } from "@stomp/stompjs";
import "./ChatWidget.css";

let stompClient: Client | null = null;

interface Message {
  id?: number;
  sender: string;
  content: string;
  sentAt?: string;
}

interface ChatWidgetProps {
  sessionId: number;
  username: string;
  token: string;
}

interface ChatInputProps {
  sendMessage: (content: string) => void;
}

const ChatInput: React.FC<ChatInputProps> = ({ sendMessage }) => {
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (input.trim() !== "") {
      sendMessage(input);
      setInput("");
    }
  };

  return (
    <div className="chat-input">
      <input
        type="text"
        value={input}
        placeholder="Type a message..."
        onChange={e => setInput(e.target.value)}
        onKeyDown={e => e.key === "Enter" && handleSend()}
      />
      <button onClick={handleSend}>Send</button>
    </div>
  );
};

const ChatWidget: React.FC = () => {
  const [open, setOpen] = useState(false);
  const [connected, setConnected] = useState(false);
  const [messages, setMessages] = useState<{ sender: string; content: string }[]>([]);

  const username = "defaultuser"; // later replace with logged-in user

  const connect = () => {
    stompClient = new Client({
      webSocketFactory: () => new SockJS("http://localhost:8080/ws-chat"),
      onConnect: () => {
        setConnected(true);
        stompClient!.subscribe(`/topic/chat/52`, (msg: any) => {
          const payload = JSON.parse(msg.body);
          setMessages(prev => [...prev, { sender: payload.sender.username, content: payload.content }]);
        });
      },
    });
    stompClient.activate();
  };

  const sendMessage = (content: string) => {
    if (stompClient && stompClient.connected) {
      const chatMessage = {
        sender: username,
        receiver: "agent",
        content,
        messageType: "TEXT"
      };
      stompClient.publish({
        destination: "/app/chat.sendMessage",
        body: JSON.stringify(chatMessage)
      });
    }
  };

  useEffect(() => {
    if (open && !connected) connect();
  }, [open]);

  return (
    <>
      {/* Floating Button */}
      <button className="chat-cta" onClick={() => setOpen(!open)}>
        💬
      </button>

      {/* Popup Chat Panel */}
      {open && (
        <div className="chat-popup">
          <div className="chat-header">Visiomatix Support</div>
          <div className="chat-body">
            {messages.map((m, i) => (
              <div key={i} className={m.sender === username ? "msg user" : "msg agent"}>
                <b>{m.sender}:</b> {m.content}
              </div>
            ))}
          </div>
          <ChatInput sendMessage={sendMessage} />
        </div>
      )}
    </>
  );
};

export default ChatWidget;
